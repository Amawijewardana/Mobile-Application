from firebase_admin import credentials

# Path to your Firebase credentials file
FIREBASE_CRED = credentials.Certificate("firebase_credentials.json")
